// eslint-disable-next-line no-unused-vars
import { motion } from "framer-motion";

export default function Hero() {
  return (
    <section
      className="relative flex min-h-screen items-center justify-center
                 md:pl-[17rem] px-8"
    >
      {/* --------------------------------- CARD -------------------------------- */}
      <motion.div
        initial={{ x: -120, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 1, ease: [0.2, 0.8, 0.2, 1] }}
        className="group relative mx-auto w-full max-w-6xl grid overflow-hidden
                   rounded-md bg-primary-light/60 backdrop-blur-sm shadow-lg
                   md:grid-cols-2"
        style={{ boxShadow: "0 0 0 1px rgba(0,81,255,0.3) inset" }}
      >
        {/* ----------------------------- LEFT  COPY ----------------------------- */}
        <div className="p-12 md:p-16">
          {/* heading + animated underline */}
          <div className="group">
            <h1 className="text-5xl font-display font-bold leading-tight">
              Innovating Catastrophe&nbsp;Risk Modeling
            </h1>
            <div
              className="mt-6 h-1 w-24 bg-accent
                         transition-[width] duration-500 group-hover:w-32"
            />
          </div>

          {/* blurb */}
          <p className="mt-6 max-w-md text-slate-300">
            We fuse Ω‑Robustness with machine‑learning interpretability to turn
            uncertainty into opportunity and protect capital against systemic
            shocks.
          </p>

          {/* CTA button */}
          <a
            href="/solution"
            className="mt-10 inline-block bg-accent px-10 py-3 text-sm font-semibold
                       tracking-widest text-primary transition
                       hover:-translate-y-0.5 hover:brightness-110
                       hover:shadow-[0_0_12px_#0051ff]"
          >
            LEARN MORE
          </a>
        </div>

        {/* ---------------------------- RIGHT  VISUAL --------------------------- */}
        <div className="relative hidden md:block">
          {/* drop a looping tech gif / mp4 converted to gif in /public */}
          <img
            src="/circuit-loop.gif"
            alt=""
            className="h-full w-full object-cover opacity-80"
          />
          {/* faint inner ring */}
          <span className="absolute inset-0 rounded-md ring-1 ring-accent/20" />
        </div>

        {/* sweeping scan‑line */}
        <span
          aria-hidden
          className="pointer-events-none absolute inset-0 -z-10
                     bg-gradient-to-b from-transparent via-accent/15 to-transparent
                     animate-scanLine mix-blend-screen"
        />
      </motion.div>
    </section>
  );
}
