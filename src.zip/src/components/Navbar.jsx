import { Link, NavLink } from "react-router-dom";
import logo from "/logo.png";
import { Menu } from "lucide-react";
import { useState } from "react";

const links = [
  { name: "Home", to: "/" },
  { name: "About", to: "/about" },
  { name: "Solution", to: "/solution" },
  { name: "Methodology", to: "/methodology" },
  { name: "Leadership", to: "/leadership" },
  { name: "Contact", to: "/contact" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <header className="fixed inset-x-0 top-0 z-50 bg-primary/80 md:hidden …">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 md:px-6">
        <Link to="/" className="flex items-center gap-2 text-xl font-bold">
          <img src={logo} alt="Apex Analytica logo" className="h-8 w-8" />
          Apex&nbsp;Analytica
        </Link>

        <nav className="hidden md:flex md:gap-6">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              className={({ isActive }) =>
                `font-medium transition hover:text-accent ${
                  isActive ? "text-accent" : ""
                }`
              }
            >
              {l.name}
            </NavLink>
          ))}
        </nav>

        <button
          className="md:hidden"
          onClick={() => setOpen((o) => !o)}
          aria-label="Toggle menu"
        >
          <Menu />
        </button>
      </div>

      {open && (
        <nav className="flex flex-col gap-4 bg-primary px-6 pb-6 md:hidden">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              onClick={() => setOpen(false)}
              className={({ isActive }) =>
                `font-medium transition hover:text-accent ${
                  isActive ? "text-accent" : ""
                }`
              }
            >
              {l.name}
            </NavLink>
          ))}
        </nav>
      )}
    </header>
  );
}
