import { NavLink, useLocation } from "react-router-dom";
import { useMemo } from "react";

const LINKS = [
  { label: "Home", to: "/" },
  { label: "About", to: "/about" },
  { label: "Solution", to: "/solution" },
  { label: "Methodology", to: "/methodology" },
  { label: "Leadership", to: "/leadership" },
  { label: "Contact", to: "/contact" },
];

export default function Sidebar() {
  const { pathname } = useLocation();
  const active = useMemo(
    () => LINKS.findIndex((l) => l.to === (pathname === "/" ? "/" : pathname)),
    [pathname]
  );

  return (
    <aside className="fixed top-28 left-10 z-30 hidden w-56 md:block">
      <nav className="relative flex flex-col gap-6">
        <span
          aria-hidden
          className="absolute -left-4 h-4 w-px bg-accent transition-all duration-500"
          style={{ transform: `translateY(${active * 40}px)` }}
        />
        {LINKS.map((l) => (
          <NavLink
            key={l.to}
            to={l.to}
            className={({ isActive }) =>
              `pl-6 text-sm tracking-widest transition ${
                isActive ? "text-accent" : "text-slate-400 hover:text-white"
              }`
            }
          >
            {l.label}
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}

