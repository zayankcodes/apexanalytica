export default function HeaderBar() {
    return (
      <header className="fixed top-0 left-0 right-0 z-40 flex items-center gap-6
                         bg-primary/80 backdrop-blur-sm py-4 pl-8 pr-6">
        <img src="/logo-full.png" alt="" className="h-10 w-auto select-none" />
        <h1 className="text-3xl font-display font-semibold tracking-[0.3em] text-accent">
          APEX&nbsp;ANALYTICA
        </h1>
        {/* rule fills ~50% of width */}
        <div className="ml-8 flex-1 min-w-[40%] border-t border-accent/20" />
      </header>
    );
  }
  