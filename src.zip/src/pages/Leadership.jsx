import { Reveal } from "../hooks/useReveal";

export default function Leadership() {
  const people = [
    {
      name: "Junaid G.",
      role: "Founder & Chief Scientist",
      bio: "Inventor of Ω‑Robustness and author of 7 peer‑reviewed papers on tail‑risk.",
    },

  ];

  return (
    <section className="mx-auto max-w-4xl space-y-12 px-4 py-24">
      <Reveal>
        <h1 className="text-4xl font-bold">Leadership</h1>
      </Reveal>

      {people.map((p, i) => (
        <Reveal key={p.name} delay={0.1 + i * 0.1}>
          <div className="flex flex-col gap-6 md:flex-row md:items-center">
            <div className="h-28 w-28 shrink-0 rounded-full bg-accent/20" />
            <div>
              <h2 className="text-xl font-semibold">{p.name}</h2>
              <p className="text-sm text-slate-300">{p.role}</p>
              <p className="mt-2 text-slate-200">{p.bio}</p>
            </div>
          </div>
        </Reveal>
      ))}
    </section>
  );
}
