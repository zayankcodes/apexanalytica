import { Reveal } from "../hooks/useReveal";

export default function About() {
  return (
    <section className="mx-auto max-w-4xl space-y-8 px-4 py-24">
      <Reveal>
        <h1 className="text-4xl font-bold">About Us</h1>
      </Reveal>

      <Reveal delay={0.1}>
        <p>
        Founded in XX, <strong>Apex Analytica empowers reinsurance firms with data-driven insights to detect and mitigate bias in risk calculation.</strong> Our platform aggregates and analyzes real-time data from diverse sources—critical for reinsurance, where emerging risks and market shifts demand swift, informed decisions. Leveraging proprietary machine learning and statistical models, we uncover hidden patterns and deliver actionable intelligence. By redefining robustness in risk assessment, we help firms refine pricing strategies and ensure fairness in insurance rate-setting - turning data into a competitive advantage.
        </p>
      </Reveal>

      <div className="grid gap-6 md:grid-cols-3">
        {[
          { stat: "XX", label: "better tail‑fit vs. conventional CAT models" },
          { stat: "XX", label: "synthetic scenarios generated" },
          { stat: "XX", label: "global clients & partners" },
        ].map((s, i) => (
          <Reveal key={s.stat} delay={0.2 + i * 0.1}>
            <div className="rounded-xl bg-primary-light p-6 text-center shadow">
              <p className="text-3xl font-extrabold text-accent">{s.stat}</p>
              <p className="mt-2 text-sm text-slate-300">{s.label}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
