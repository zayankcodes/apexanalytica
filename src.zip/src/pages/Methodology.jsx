import { Reveal } from "../hooks/useReveal";

export default function Methodology() {
  const papers = [
    "Catastrophe Modelling through PRO & DRO",
    "Beyond Black Swans: Chaotic AI Emergence Dynamics",
    "Illuminating the Black Box: Integrating Ω‑Robustness with Mechanistic Interpretability",
    "Modeling Catastrophic Forgetting in Neural Networks",
  ];

  return (
    <section className="mx-auto max-w-5xl space-y-10 px-4 py-24">
      <Reveal>
        <h1 className="text-4xl font-bold">Methodology</h1>
      </Reveal>

      <Reveal delay={0.1}>
        <p>
          Ω‑Robustness blends <em>Pareto Robust Optimisation</em> with
          <em> Distributionally Robust Optimisation</em> to create an uncertainty
          set Ω that captures rare yet scientifically plausible extremes.
          Multi‑objective search then minimises probability of trigger, expected
          payout and worst‑case loss—subject to diversification constraints
          derived from our peer‑reviewed studies.
        </p>
      </Reveal>

      <Reveal delay={0.2}>
        <p>
          Mechanistic interpretability tools (SHAP, LIME, feature‑visualisation)
          illuminate model pathways, reducing the risk of malignant Systems‑2
          behaviours documented in our AI‑safety papers.
        </p>
      </Reveal>

      <Reveal delay={0.3}>
        <h2 className="mt-10 text-2xl font-semibold">Key Publications</h2>
      </Reveal>

      <ul className="list-disc space-y-4 pl-6">
        {papers.map((p, i) => (
          <Reveal key={p} delay={0.35 + i * 0.05}>
            <li className="text-slate-200">{p}</li>
          </Reveal>
        ))}
      </ul>
    </section>
  );
}
