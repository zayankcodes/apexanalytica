import { Reveal } from "../hooks/useReveal";

export default function Solution() {
  return (
    <section className="mx-auto max-w-5xl space-y-10 px-4 py-24">
      <Reveal>
        <h1 className="text-4xl font-bold">Our Solution</h1>
      </Reveal>

      <Reveal delay={0.1}>
        <p>
          Apex Analytica delivers a three‑layer platform that transforms raw data
          into actionable intelligence:
        </p>
      </Reveal>

      <ol className="list-decimal space-y-6 pl-6">
        {[
          [
            "Reporting.",
            "Unified data pipelines ingest climate, IoT and portfolio exposure files, then surface clean, version‑controlled datasets.",
          ],
          [
            "Forecasting.",
            "Ω‑Robustness stress‑tests thousands of synthetic scenarios, optimising for probability of trigger, expected payout and maximum loss.",
          ],
          [
            "Recommending.",
            "Interactive dashboards translate complex risk surfaces into clear capital‑allocation and underwriting guidance.",
          ],
        ].map(([title, copy], i) => (
          <Reveal key={title} delay={0.2 + i * 0.1}>
            <li>
              <strong>{title}</strong> {copy}
            </li>
          </Reveal>
        ))}
      </ol>
    </section>
  );
}
