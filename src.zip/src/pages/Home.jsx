import Hero from "../components/Hero";
import { Reveal } from "../hooks/useReveal";

export default function Home() {
  return (
    <>
      <Hero />

      <section className="mx-auto max-w-5xl space-y-10 px-4 py-20">
        <Reveal>
          <h2 className="text-3xl font-bold">
            Innovating Risk Assessment for Modern Challenges
          </h2>
        </Reveal>

        <Reveal delay={0.1}>
          <p>
            Apex Analytica builds next‑generation catastrophe analytics that
            illuminate <em>long‑tail</em> threats lurking inside climate,
            financial and AI systems. Our proprietary Ω‑Robustness framework
            synthesises rare‑event data, stress‑tests black‑box models, and
            surfaces insights that traditional tools miss.
          </p>
        </Reveal>

        <div className="grid gap-8 md:grid-cols-3">
          {[
            {
              title: "Research",
              copy:
                "Peer‑reviewed studies on catastrophic forgetting, climate tail‑risk and malignant Systems‑2 AI.",
              link: "/methodology",
            },
            {
              title: "Platform",
              copy:
                "Modular APIs that plug Ω‑Robustness into actuarial, ESG and AI‑safety workflows.",
              link: "/solution",
            },
            {
              title: "Advisory",
              copy:
                "Strategic engagements with reinsurers, sovereign funds and regulators worldwide.",
              link: "/contact",
            },
          ].map((c, i) => (
            <Reveal key={c.title} delay={0.2 + i * 0.1}>
              <a
                href={c.link}
                className="group relative overflow-hidden rounded-2xl bg-primary-light p-6 shadow transition hover:-translate-y-1 hover:shadow-lg"
              >
                {/* accent bar */}
                <span
                  aria-hidden
                  className="absolute left-0 top-0 h-full w-6 rounded-r-full bg-accent/40 transition-all duration-300 group-hover:w-8"
                />

                {/* card content sits above the bar */}
                <div className="relative z-10">
                  <h3 className="mb-2 text-xl font-semibold group-hover:text-accent">
                    {c.title}
                  </h3>
                  <p className="text-sm text-slate-200">{c.copy}</p>
                </div>
              </a>
            </Reveal>
          ))}
        </div>
      </section>
    </>
  );
}
